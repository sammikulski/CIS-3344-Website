package view;

// classes imported from java.sql.*
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import reservationModel.*;

// classes in my project
import dbUtils.*;

public class ReservationView {

    public static StringDataList getAllReservations(DbConn dbc) {

        //PreparedStatement stmt = null;
        //ResultSet results = null;
        StringDataList sdl = new StringDataList();
        try {
            String sql = "SELECT reservation_id, reservation_name, reservation_imgURL, check_in, check_out, num_night "+
                    "FROM reservation_t ORDER BY reservation_id ";  // always order by something, not just random order.
            PreparedStatement stmt = dbc.getConn().prepareStatement(sql);
            ResultSet results = stmt.executeQuery();
            while (results.next()) {
                sdl.add(results);
            }
            results.close();
            stmt.close();
        } catch (Exception e) {
            StringData sd = new StringData();
            sd.errorMsg = "Exception thrown in ReservationView.listReservationsAPI(): " + e.getMessage();
            sdl.add(sd);
        }
        return sdl;
    }

}