package model.xxx;

import dbUtils.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DbMods {
    
   // here you would have methods for insert, update, and delete

} // class
