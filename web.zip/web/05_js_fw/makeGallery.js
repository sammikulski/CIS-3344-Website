"use strict";

function makePicGallery(id, array) {
    //vars:
    var imgcontainer = array;
    var fullSize = document.getElementById("fullsize"); //big image div 
    var iconPic = document.getElementById("icons"); //small image div
    var displayPic = document.createElement("img");  //creates the big picture itself
    var caption = document.getElementById("captions");  //caption
    
    //when website loads, first pic we see:
    displayPic.src = imgcontainer[0].imgFileName;
    fullSize.appendChild(displayPic);
    caption.innerHTML = imgcontainer[0].caption;
    
    for (var i = 0; i < imgcontainer.length; i++) {
        {
            var displayIcon= document.createElement("img"); //creates each icon pic
            displayIcon.src = imgcontainer[i].imgFileName;
            displayIcon.caption = imgcontainer[i].caption;
            iconPic.appendChild(displayIcon);
            //when an icon is clicked, display the corresponding pic
            displayIcon.onclick = function () { 
                displayPic.src = this.src;
                caption.innerHTML = this.caption;
            };
        }
    }
}